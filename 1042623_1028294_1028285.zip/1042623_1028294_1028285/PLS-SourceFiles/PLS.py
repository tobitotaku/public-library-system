# entrypoint of the application
# from config import configurationhelper

from controllers.maincontroller import *

MainCV().render_menu()
